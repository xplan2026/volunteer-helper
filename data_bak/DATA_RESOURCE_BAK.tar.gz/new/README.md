数据来源：https://www.cqksy.cn/uploadFile/infopub/202507/1947199748985856000.pdf?fileName=2025xxb-Bkp_WLPx0721.pdf&fileSize=1033364


三步执行完成，总结：

|步骤	|文件	|记录数	|操作|
|---|---|---|---|
|源文件	|resource.json	|11,086	|—|
|Step 1	|step1.json	|4,090	|删除4个同分排序字段 + 筛选479-529分|
|Step 2	|step2.json	|2,849	|剔除10个指定省份|
|Step 3	|step3.json	|70	|筛选6个专业关键词 + 学校含"铁路"|
